﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web.Services;

namespace DatabaseWebServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IDatabaseAPI" in both code and config file together.
    [ServiceContract]
    public interface IDatabaseAPI
    {
        [OperationContract]
        int InserDetail(string firstName,string lastName,DateTime dob);
        [OperationContract]
        void GetDetail();
        [OperationContract]
        int UpdateDetail(string firstName, string lastName, DateTime dob);
        [OperationContract]
        int DeleteDetail(int Id);
        [OperationContract]
        WebService_dsingh58 SearchDetail(int id);

    }
}
