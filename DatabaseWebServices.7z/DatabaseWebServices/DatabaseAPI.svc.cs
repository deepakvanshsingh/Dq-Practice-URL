﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Windows;

namespace DatabaseWebServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "DatabaseAPI" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select DatabaseAPI.svc or DatabaseAPI.svc.cs at the Solution Explorer and start debugging.
    public class DatabaseAPI : IDatabaseAPI
    {
        Training_23Jan20_PuneEntities studentContext = new Training_23Jan20_PuneEntities();
        WebService_dsingh58 student = new WebService_dsingh58();
        public int DeleteDetail(int Id)
        {
            int status = 0;
            try
            {
                student = studentContext.WebService_dsingh58.ToList().Find(val => val.Id == Id);
                if (student != null)
                {
                    studentContext.WebService_dsingh58.Remove(student);
                    studentContext.SaveChanges();
                    status = 1;
                }
                else
                {
                    status = 0;
                }
                
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return status;
        }

        public void GetDetail()
        {
            throw new NotImplementedException();
        }

        public int InserDetail(string firstName, string lastName, DateTime Dob)
        {
            int status=0;
            try
            {
                student.FirstName = firstName;
                student.LastName = lastName;
                student.Dob = Dob;
                studentContext.WebService_dsingh58.Add(student);
               status = studentContext.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error"+ex.Message,"Error",MessageBoxButton.OK,MessageBoxImage.Error);
            }
            return status;
        }

        public WebService_dsingh58 SearchDetail(int id)
        {
            try
            {
                student = studentContext.WebService_dsingh58.ToList().Find(val => val.Id == id);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return student;
        }

        public int UpdateDetail(string firstName, string lastName, DateTime Dob)
        {
            throw new NotImplementedException();
        }
    }
}
